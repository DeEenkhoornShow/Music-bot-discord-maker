// Start app with API key.
require('dotenv').config({
    path: './pw.env'
})
// Login with Key
require('./config/Discord')