const // Require all the Channels from this folder
    nappyTube = require('./nappy-tube')
// Make a list of all the channels
const channels = [
    nappyTube

]
// Export the channels to be used in onMessage.js
exports.channels = channels