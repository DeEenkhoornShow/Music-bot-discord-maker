const PlaylistNames = [
    "Top_200",
    "Top_Artists_Top_Tracks"
]
PlaylistNames.formatted = [
    "top 200",
    "top artists top tracks"
]

module.exports.PlaylistNames = PlaylistNames;